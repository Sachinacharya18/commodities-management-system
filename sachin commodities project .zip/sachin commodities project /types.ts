
export enum UserRole {
  MANAGER = 'MANAGER',
  STORE_KEEPER = 'STORE_KEEPER'
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
}

export interface Commodity {
  id: string;
  name: string;
  category: 'Metals' | 'Energy' | 'Agriculture' | 'Livestock';
  price: number;
  unit: string;
  stock: number;
  status: 'In Stock' | 'Low Stock' | 'Out of Stock';
  lastUpdated: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface MarketInsight {
  title: string;
  content: string;
  sentiment: 'Positive' | 'Neutral' | 'Negative';
}
