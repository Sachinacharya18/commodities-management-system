
import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { Commodity, MarketInsight } from '../types';
import { fetchMarketInsights } from '../services/geminiService';

interface DashboardProps {
  commodities: Commodity[];
}

const Dashboard: React.FC<DashboardProps> = ({ commodities }) => {
  const [insights, setInsights] = useState<MarketInsight[]>([]);
  const [loadingInsights, setLoadingInsights] = useState(true);

  useEffect(() => {
    const loadInsights = async () => {
      setLoadingInsights(true);
      const res = await fetchMarketInsights(commodities);
      setInsights(res);
      setLoadingInsights(false);
    };
    loadInsights();
  }, [commodities]);

  const stats = [
    { name: 'Total Commodities', value: commodities.length, icon: '📦' },
    { name: 'Low Stock Items', value: commodities.filter(c => c.status === 'Low Stock').length, icon: '⚠️' },
    { name: 'Total Assets (Val)', value: `$${(commodities.reduce((acc, c) => acc + (c.price * c.stock), 0) / 1000).toFixed(1)}K`, icon: '💰' },
    { name: 'Active Orders', value: '12', icon: '🚚' },
  ];

  const dataByCategory = commodities.reduce((acc: any, curr) => {
    const found = acc.find((item: any) => item.name === curr.category);
    if (found) {
      found.value += 1;
    } else {
      acc.push({ name: curr.category, value: 1 });
    }
    return acc;
  }, []);

  const chartData = commodities.slice(0, 5).map(c => ({
    name: c.name,
    stock: c.stock,
    price: c.price
  }));

  const COLORS = ['#0ea5e9', '#6366f1', '#f59e0b', '#10b981'];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <span className="text-2xl">{stat.icon}</span>
              <span className="text-xs font-bold px-2 py-1 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full">+4.5%</span>
            </div>
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">{stat.name}</p>
            <h3 className="text-2xl font-bold text-slate-800 dark:text-white mt-1">{stat.value}</h3>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Charts Section */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-6">Inventory Levels</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="stock" fill="#0ea5e9" radius={[6, 6, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-6">Category Distribution</h3>
            <div className="h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={dataByCategory}
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {dataByCategory.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2 pr-8">
                {dataByCategory.map((cat: any, i: number) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{backgroundColor: COLORS[i % COLORS.length]}}></div>
                    <span className="text-xs text-slate-600 dark:text-slate-400">{cat.name} ({cat.value})</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Gemini Market Insights Sidebar */}
        <div className="space-y-8">
          <div className="bg-primary-600 rounded-3xl p-6 text-white shadow-lg shadow-primary-600/30 overflow-hidden relative">
             <div className="relative z-10">
                <div className="flex items-center gap-2 mb-4">
                   <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">✨</div>
                   <h3 className="font-bold text-lg">Market AI Insights</h3>
                </div>
                <p className="text-primary-100 text-sm mb-6">Real-time analysis of your commodity portfolio generated by Gemini AI.</p>
                
                <div className="space-y-4">
                  {loadingInsights ? (
                    <div className="animate-pulse space-y-4">
                      {[1,2,3].map(i => <div key={i} className="h-20 bg-white/10 rounded-xl"></div>)}
                    </div>
                  ) : (
                    insights.map((insight, idx) => (
                      <div key={idx} className="bg-white/10 backdrop-blur-sm p-4 rounded-xl border border-white/10 hover:bg-white/20 transition-colors">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-bold">{insight.title}</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                            insight.sentiment === 'Positive' ? 'bg-green-500/30 text-green-200' :
                            insight.sentiment === 'Negative' ? 'bg-red-500/30 text-red-200' :
                            'bg-blue-500/30 text-blue-200'
                          }`}>
                            {insight.sentiment}
                          </span>
                        </div>
                        <p className="text-xs text-primary-50/80 leading-relaxed">{insight.content}</p>
                      </div>
                    ))
                  )}
                </div>
             </div>
             {/* Decorative circle */}
             <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
          </div>

          <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm">
             <h3 className="font-bold text-slate-800 dark:text-white mb-4">Quick Tasks</h3>
             <div className="space-y-3">
                {['Approve crude oil shipment', 'Check wheat quality audit', 'Update silver pricing'].map((task, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-900/50 rounded-xl group cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors">
                    <div className="w-5 h-5 border-2 border-slate-300 dark:border-slate-600 rounded flex items-center justify-center group-hover:border-primary-500 transition-colors"></div>
                    <span className="text-sm text-slate-700 dark:text-slate-300">{task}</span>
                  </div>
                ))}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
