
import { GoogleGenAI } from "@google/genai";
import { Commodity, MarketInsight } from "../types";

export const fetchMarketInsights = async (commodities: Commodity[]): Promise<MarketInsight[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
    
    const commodityList = commodities.map(c => `${c.name} (${c.category}): $${c.price} ${c.unit}`).join(', ');
    
    const prompt = `Based on this current inventory of commodities: ${commodityList}, generate 3 brief, high-level market insights. For each insight, provide a title, a one-sentence content piece, and a sentiment (Positive, Neutral, or Negative). Format as JSON array of objects.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const text = response.text || "[]";
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback data if API fails
    return [
      { title: "Market Volatility", content: "Expect short-term price fluctuations in energy sectors due to geopolitical shifts.", sentiment: "Neutral" },
      { title: "Metals Outlook", content: "Precious metals maintain strong resistance levels despite inflationary pressures.", sentiment: "Positive" },
      { title: "Supply Chain Alert", content: "Agricultural stocks are seeing localized shortages in the eastern corridor.", sentiment: "Negative" }
    ];
  }
};
