
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Commodity, User, UserRole } from './types';
import { INITIAL_COMMODITIES, AUTH_STORAGE_KEY } from './constants';
import Login from './views/Login';
import Dashboard from './views/Dashboard';
import Inventory from './views/Inventory';
import Layout from './components/Layout';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [commodities, setCommodities] = useState<Commodity[]>(INITIAL_COMMODITIES);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedAuth = localStorage.getItem(AUTH_STORAGE_KEY);
    if (storedAuth) {
      setUser(JSON.parse(storedAuth));
    }
    setIsLoading(false);
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem(AUTH_STORAGE_KEY);
  };

  if (isLoading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900">
        <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <HashRouter>
      <Layout user={user} onLogout={handleLogout}>
        <Routes>
          <Route 
            path="/dashboard" 
            element={
              user.role === UserRole.MANAGER ? (
                <Dashboard commodities={commodities} />
              ) : (
                <Navigate to="/inventory" replace />
              )
            } 
          />
          <Route 
            path="/inventory" 
            element={
              <Inventory 
                commodities={commodities} 
                role={user.role} 
                onUpdate={setCommodities} 
              />
            } 
          />
          <Route path="*" element={<Navigate to={user.role === UserRole.MANAGER ? "/dashboard" : "/inventory"} replace />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
};

export default App;
