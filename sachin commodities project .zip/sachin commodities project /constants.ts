
import { Commodity, UserRole } from './types';

export const MOCK_USERS = [
  {
    id: '1',
    email: 'manager@commodityx.com',
    name: 'Sarah Manager',
    role: UserRole.MANAGER,
    password: 'password123'
  },
  {
    id: '2',
    email: 'keeper@commodityx.com',
    name: 'John Keeper',
    role: UserRole.STORE_KEEPER,
    password: 'password123'
  }
];

export const INITIAL_COMMODITIES: Commodity[] = [
  { id: 'c1', name: 'Gold', category: 'Metals', price: 2150.50, unit: 'oz', stock: 120, status: 'In Stock', lastUpdated: '2024-03-20' },
  { id: 'c2', name: 'Crude Oil', category: 'Energy', price: 82.15, unit: 'barrel', stock: 5000, status: 'In Stock', lastUpdated: '2024-03-20' },
  { id: 'c3', name: 'Wheat', category: 'Agriculture', price: 540.20, unit: 'ton', stock: 25, status: 'Low Stock', lastUpdated: '2024-03-19' },
  { id: 'c4', name: 'Silver', category: 'Metals', price: 24.80, unit: 'oz', stock: 850, status: 'In Stock', lastUpdated: '2024-03-20' },
  { id: 'c5', name: 'Natural Gas', category: 'Energy', price: 1.75, unit: 'MMBtu', stock: 0, status: 'Out of Stock', lastUpdated: '2024-03-18' },
  { id: 'c6', name: 'Coffee', category: 'Agriculture', price: 185.30, unit: 'lb', stock: 450, status: 'In Stock', lastUpdated: '2024-03-20' },
  { id: 'c7', name: 'Copper', category: 'Metals', price: 4.12, unit: 'lb', stock: 1200, status: 'In Stock', lastUpdated: '2024-03-20' },
  { id: 'c8', name: 'Corn', category: 'Agriculture', price: 435.00, unit: 'bushel', stock: 15, status: 'Low Stock', lastUpdated: '2024-03-19' },
];

export const APP_THEME_KEY = 'commodityx-theme';
export const AUTH_STORAGE_KEY = 'commodityx-auth';
